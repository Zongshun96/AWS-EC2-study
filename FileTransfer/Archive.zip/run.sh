#!/usr/bin/env python3
python ./test.py 1 2
